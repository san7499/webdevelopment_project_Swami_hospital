const navBar = document.getElementById('nav-bar');
const homeSection = document.getElementById('home');
const makeAppointmentBtn = document.getElementById('make-appointment-btn');
const servicesList = document.getElementById('services-list');
const departmentsList = document.getElementById('departments-list');
const doctorsList = document.getElementById('doctors-list');
const contactForm = document.getElementById('contact-form');
const submitBtn = document.getElementById('submit-btn');
const appointmentForm = document.getElementById('appointment-form');
const bookAppointmentBtn = document.getElementById('book-appointment-btn');
const appointmentDoctorSelect = document.getElementById('appointment-doctor');

makeAppointmentBtn.addEventListener('click', () => {
    scrollToSection('appointments');
});

submitBtn.addEventListener('click', (e) => {
    e.preventDefault();
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;
    console.log(`Name: ${name}, Email: ${email}, Message: ${message}`);
});

bookAppointmentBtn.addEventListener('click', (e) => {
    e.preventDefault();
    const appointmentDate = document.getElementById('appointment-date').value;
    const appointmentTime = document.getElementById('appointment-time').value;
    const appointmentDoctor = appointmentDoctorSelect.value;
    console.log(`Appointment: ${appointmentDate} at ${appointmentTime} with ${appointmentDoctor}`);
});

const departments = ['Pediatrics', 'Orthopedics', 'Neurology', 'Gynecology', 'Urology', 'Ophthalmology'];
departments.forEach(department => {
    const listItem = document.createElement('li');
    listItem.textContent = department;
    departmentsList.appendChild(listItem);
});

const doctors = [
    { name: 'Dr. John Doe', speciality: 'Cardiologist' },
    { name: 'Dr. Jane Smith', speciality: 'Dermatologist' },
    { name: 'Dr. Michael Johnson', speciality: 'Neurologist' },
    { name: 'Dr. Sarah Lee', speciality: 'Gynecologist' },
    { name: 'Dr. David Kim', speciality: 'Urologist' },
    { name: 'Dr. Emily Chen', speciality: 'Ophthalmologist' }
];

doctors.forEach(doctor => {
    const doctorDiv = document.createElement('div');
    doctorDiv.textContent = `${doctor.name} - ${doctor.speciality}`;
    doctorsList.appendChild(doctorDiv);

    const doctorOption = document.createElement('option');
    doctorOption.value = doctor.name;
    doctorOption.textContent = doctor.name;
    appointmentDoctorSelect.appendChild(doctorOption);
});

function scrollToSection(sectionId) {
    const section = document.getElementById(sectionId);
    const navBarHeight = navBar.offsetHeight;
    const sectionPosition = section.offsetTop - navBarHeight;
    window.scrollTo({
        top: sectionPosition,
        behavior: 'smooth'
    });
}
